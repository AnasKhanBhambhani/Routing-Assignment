import React from 'react'
import Header from './Header'

const About = () => {
  return (
    <div>
        <Header/>
        <div className='text-center w-full h-[90vh] flex justify-center items-center'>
        About is without protected.
      </div>
    </div>
  )
}

export default About
