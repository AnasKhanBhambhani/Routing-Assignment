import React from 'react'
import { Link } from 'react-router-dom'
import Header from './Header'

const Home = () => {
  return (
    <div>
      <Header />
      <div className='text-center w-full h-[90vh] flex justify-center items-center'>
        this is Home
      </div>
    </div>
  )
}

export default Home
