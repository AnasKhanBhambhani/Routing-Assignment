import React from 'react'
import { Link, Outlet } from 'react-router-dom';

const Header = () => {
  return (
    <div>
      <nav>
    <ul className='flex gap-4 bg-purple-400 p-5'>
        <li><Link to='/'>Home</Link></li>
        <li><Link to='/about'>About</Link></li>
        <li><Link to='/blog'>Blog</Link></li>
        <li><Link to='/login'>login</Link></li>

    </ul>
</nav>
    </div>
  )
}

export default Header
