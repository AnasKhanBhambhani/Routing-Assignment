import React, { useState } from 'react'
import { json, Outlet, useNavigate, useParams } from 'react-router-dom'
import data from './Data.json'
import { Link } from 'react-router-dom';
import Header from './Header';
const BlogPost = () => {
    const param = useParams();
    const navigate = useNavigate();
    const { id } = param;
    const post = data.find(post => post.id === JSON.parse(id));
    const [toggle, setToggle] = useState(true);

    function handleClick(id) {
        navigate('blogdetail', { state: { postId: id } })
        setToggle(!toggle);
    }

    return (
        <>
            <Header />
            <div className='w-[100vw] h-[100vh] flex flex-col items-center'>
                <div className='my-3 text-3xl font-bold'><h1>BlogPost</h1></div>
                <div>

                    <div className=' mx-3 p-8 rounded shadow-2xl cursor-pointer flex flex-col justify-center items-center'>
                        <h1 className='text-2xl font-bold'>{post.title}</h1>
                        <div className='flex flex-col  gap-6'>
                            <h3><i>Author : {post.author}</i> </h3>
                            <p>Content : {post.content}</p>
                            {!toggle && (

                            <Outlet />
                            )}
                            <div>
                                <button onClick={() => { handleClick(post.id) }} className='bg-purple-700 px-4 py-2 rounded'>{toggle?'read more ':'hide it'}</button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default BlogPost
