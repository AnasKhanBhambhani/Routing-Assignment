import React from 'react'
import Header from './Header';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import data from './Data.json';

const Blog = () => {

    return (
        <div>
            <Header />
            <div className='flex  my-8 flex-col'>
                <div className='flex my-7 justify-center'>
                    <h1 className='text-3xl font-bold'>
                        This is my blogs page
                    </h1>
                </div>
                <div className='bg-purple-300 grid grid-cols-1 sm:grid-cols-1 mx-2 rounded md:grid-cols-1 lg:grid-cols-1 gap-1 p-4'>
                    {data.map((post) => {
                        return (
                           <>
                            <Link to={`/blogpost/${post.id}`}>
                                <div className='bg-slate-50 p-1 rounded shadow-xl cursor-pointer hover:translate-x-1' key={post.id}>
                                    <h1 className='text-2xl font-bold'>{post.title}</h1>
                                    <h3><i>{post.author}</i> </h3>
                                    <p>{post.content.slice(0, 100)}....</p>
                                </div>
                            </Link>
                           </>
                        )
                    })}
                </div>
            </div>
        </div >
    )
}

export default Blog
