import React, { useEffect, useState } from 'react'
import Header from './Header'
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    const navigate = useNavigate();
    function handleForm(e) {
        e.preventDefault();
        localStorage.setItem('login',true)
        let login = localStorage.getItem('login');
        if (login) {
            navigate('/')
        }
    }
    useEffect(() => {

    },[handleForm])

    return (
        <div className=' w-[100vw] h-[100vh] flex flex-col'>
            <div>
                <Header />
            </div>
            <div className=' py-10 flex h-[100vh] justify-center items-center '>

                <form className='bg-slate-300 p-10 flex flex-col gap-8 rounded shadow-xl' onSubmit={handleForm}>
                    <div>
                        <h1 className='text-2xl font-bold'>
                            Login Here
                        </h1>
                    </div>
                    <div className='flex flex-col gap-3'>
                        <label htmlFor="email">Your Email</label>
                        <input className=' border-sky-300 ' type="email" id='email' value={name} required onChange={(e) => { setName(e.target.value) }} />
                        <label htmlFor="password">Your password</label>
                        <input type="password" id='password' value={email} required onChange={(e) => { setEmail(e.target.value) }} />
                        <div>
                            <button className='bg-purple-600 py-2 px-4 rounded' type='submit'>Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Login
