import React from 'react'
import data from './Data.json'
import { json, useLocation, useParams } from 'react-router-dom'
import Header from './Header';

const BlogDetail = () => {
  const location = useLocation();
  const { state } = location
  const post = data.find(post => post.id === JSON.parse(state.postId));

  return (
    <>
          <div className='flex flex-col  gap-6'>
            <p>summary : {post.summary}</p>
        </div>
    </>
  )
}

export default BlogDetail
