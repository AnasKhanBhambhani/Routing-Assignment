import { Outlet, Route, Routes } from "react-router-dom";
import './index.css'
import Home from "./Component/Home";
import About from "./Component/About";
import Blog from "./Component/Blog";
import BlogPost from "./Component/BlogPost";
import BlogDetail from "./Component/BlogDetail";
import Login from "./Component/Login";
import Protected from "./Component/Protected";

function App() {


  return (
    <div className=' bg-slate-200 h-[100vh] w-[100vw]   '>
      <Routes>
          <Route path="/" element={<Protected Component={Home}/>} />
        <Route path="/about" element={<About />}/>
        <Route path="/blog" element={<Protected Component={Blog}/>} />
          <Route path="/login" element={<Login/>} />

          <Route path="/blogpost/:id/" element={<Protected Component={BlogPost}/>}>
        <Route path="blogdetail" element={<Protected Component={BlogDetail}/>}/>
          </Route>
        <Route path="/*" element={<h1>404 not found</h1>}/>
      </Routes>
    </div>


  );
}

export default App;
